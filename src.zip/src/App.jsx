import React from 'react'
import Section1 from './Sections/Section1/index'
import Section2 from './Sections/Section2/index'
import Section3 from './Sections/Section3/index'
import './App.css'

function App() {


  return (
    <>
      <Section1/>
      <Section2/>
      <Section3/>
          </>
  )
}

export default App
