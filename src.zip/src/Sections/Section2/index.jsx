import React from 'react';
import Map from '../../assets/Images/world_map_PNG28 2.png';
import Rectangle from '../../assets/Images/Rectangle 15.png';
import Rectangles from '../../assets/Images/Rectangle 16.png';
import Rectangls from '../../assets/Images/Rectangle 17.png';
import './index.css';

const Index = () => {
  return (
    <div>
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="true" />
      <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap"
        rel="stylesheet"
      />

      <div className="container">
        <h1 className="OurPopular text-center mt-5">Our Popular Destinations</h1>
        <div className="Sides">
          <div className="Side">
            <img className="card-img img-fluid" src={Map} alt="Map" />
          </div>
          <div className="Side">
            <div className="card1">
              <img className="Thailand" src={Rectangle} height="200px" alt="" />
              <div className="card-text">
                <h2 className="location-title">Thailand</h2>
                <p className="details">20+ Spots | 2D & 3N</p>
              </div>
            </div>

            <div className="card2">
              <img className="Thailand" src={Rectangles} height="200px" alt="" />
              <div className="card-text">
                <h2 className="location-title">Indonesia</h2>
                <p className="details">25+ Spots | 3D & 3N</p>
              </div>
            </div>

            <div className="card3">
              <img className="Thailand" src={Rectangls} height="200px" alt="" />
              <div className="card-text">
                <h2 className="location-title">New Zealand</h2>
                <p className="details">20+ Spots | 3D & 2N</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
