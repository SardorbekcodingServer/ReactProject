import React from 'react';
import Calendar from '../../assets/Images/simple-line-icons_calender.png'
import AntDesaint from '../../assets/Images/ant-design_bar-chart-outlined.png'
import CarbonMap from '../../assets/Images/carbon_map.png'
import History from '../../assets/Images/gridicons_history.png'
import BackroundMap from '../../assets/Images/world_map_PNG28 1.png'
import './index.css'
const index = () => {
    return (
        
        <div>
            <link rel="preconnect" href="https://fonts.googleapis.com"/>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet"></link>


                <div class="container">
        <h1 class="fw-bold text-center">We always try to give you <br/> the best service</h1>
        <p class="text-center mb-3">We always try to make our customer happy. We provide all kinds of <br/> facilities. Your satisfaction is our main priority.</p>
        
        <div class="mini-cards-container">
            <div class="firtcard">
                <img class="mt-4 img-fluid" src={Calendar} alt=""/>
                <h1 class="fifteen-plus fw-bold text-center mt-3">15+</h1>
                <p class="ptext text-center">Years of <br/> Experience</p>
            </div>
            <div class="firtcard">
                <img class="mt-4 img-fluid" src={AntDesaint} alt=""/>
                <h1 class="fifteen-plus fw-bold text-center mt-3">15k+</h1>
                <p class="ptext text-center" >Happy Travellers</p>
            </div>
            <div class="firtcard">
                <img class="mt-4 img-fluid" src={CarbonMap} alt=""/>
                <h1 class="fifteen-plus fw-bold text-center mt-3">650+</h1>
                <p class="ptext text-center">Places Visited</p>
            </div> 
            <div class="firtcard">
                <img class="mt-4 img-fluid" src={History} alt=""/>
                <h1 class="fifteen-plus fw-bold text-center mt-3">2k+</h1>
                <p class="ptext text-center">Travel History</p>
            </div>
        </div>
    </div>
        </div>
    );
};

export default index;